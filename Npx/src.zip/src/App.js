//import logo from './logo.svg';
import React from 'react';
import './App.css';


const name=<span>Hello React</span>

const newElement=React.createElement('h2',{className:'newElement'},'Hello, Welcome to H2 tag')

const test=function()
{
  alert("Hello Rupesh")
}

const age=function(a)
{
  if (a>18)
  {
      return <span>"Elgible to vote</span>
  }
  else{
       return <span>"Not Elgible to vote</span>
  }
}


function App() {
  return (

    <div className="App">
      <h1>Hello Rupesh kumar, {name} </h1>
      {newElement}
      <button onClick={test}></button>
      {age(7)}
    </div>
  );
}

export default App;
